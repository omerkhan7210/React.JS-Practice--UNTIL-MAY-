let productsData = [
    {
        id:1,
        name:"Product 1",
        imgURL:"img-3.jpg"
    },
    {
        id:2,
        name:"Product 2",
        imgURL:"img-1.jpg"
    },
    {
        id:3,
        name:"Product 3",
        imgURL:"img-2.jpg"
    },
    {
        id:4,
        name:"Product 4",
        imgURL:"img-3.jpg"
    },
    {
        id:5,
        name:"Product 5",
        imgURL:"img-2.jpg"
    },
    {
        id:6,
        name:"Product 6",
        imgURL:"img-1.jpg"
    },
    {
        id:7,
        name:"Product 7",
        imgURL:"img-2.jpg"
    },
    {
        id:8,
        name:"Product 8",
        imgURL:"img-1.jpg"
    },
    {
        id:9,
        name:"Product 9",
        imgURL:"img-3.jpg"
    },
    {
        id:10,
        name:"Product 10",
        imgURL:"img-2.jpg"
    },
    {
        id:11,
        name:"Product 11",
        imgURL:"img-3.jpg"
    },
    {
        id:12,
        name:"Product 12",
        imgURL:"img-1.jpg"
    }
]

export default productsData